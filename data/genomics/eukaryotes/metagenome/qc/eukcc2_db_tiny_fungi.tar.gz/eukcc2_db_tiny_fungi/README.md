# EukCC2 database 2026_11

| | |
|---|---|
| version | **2026_11** (YYYY_MM of the cut-off date) |
| directory | `eukcc2_db_tiny_fungi/` |
| created | 2026-11-09 |
| NCBI cut-off | 2026-11-01T00:00:00+0000 |
| pipeline | eukcc-db 1.0.0, Nextflow 25.04.6 |
| tree model | LG+R7 |
| PANTHER | 16.0 |

Use it with `eukcc --db eukcc2_db_2026_11`.

## Contents

| sub-database | leaves | placement markers | alignment columns | calibrated profiles | SCMG profiles |
|---|---|---|---|---|---|
| base | 10 | 10 | 4,049 | 341 | 337 |
| fungi | 10 | 10 | 4,049 | 341 | 337 |

`base` holds every genome; `fungi`, `plant` and `protozoa` follow the NCBI division of
each genome. Only `db_base/` carries the MetaEuk reference (`metaeukdb/`).

## Sources

| input | where it came from |
|---|---|
| NCBI genomes | `https://ftp.ncbi.nlm.nih.gov/genomes/<catalogue>/<group>/assembly_summary.txt`, downloaded by the run that started on 2026-11-09 |
| NCBI taxonomy | `https://ftp.ncbi.nlm.nih.gov/pub/taxonomy/taxdump_archive/taxdmp_2026-11-01.zip` (`--taxdump`); nodes.dmp dated 2026-11-01, md5 `42a27451954fd10ddcb50f0549ab7869`, loaded with ete3 3.1.2 |
| PANTHER library | local copy `/hps/nobackup/rdf/metagenomics/service-team/users/zimmer/B03/eukcc_db_bench/panther_tiny/` (`--panther`) of `https://data.pantherdb.org/ftp/panther_library/16.0/PANTHER16.0_ascii.tgz`, version 16.0 |
| excluded genomes | `/hps/nobackup/rdf/metagenomics/service-team/users/zimmer/B03/eukcc_db_bench/eukcc_db/assets/exclude_genomes.tsv` (`--exclude_genomes`): 2 accessions, md5 `fd67ad8d7ebfc5ba125a1696082d8c29`, copied to `provenance/exclude_genomes.tsv` |

NCBI assembly summaries of this build:

| file | rows | md5 |
|---|---|---|
| `genbank_fungi.txt` | 26,819 | `9db253ca29d0bc946f706bf55900566a` |
| `refseq_fungi.txt` | 674 | `0c4572677f9687c92833cbbe38299629` |

## Parameters

| parameter | value |  |
|---|---|---|
| `--cutoff_date` | 2026-11-01T00:00:00+0000 | assemblies released up to this date |
| `--divisions` | fungi/refseq, fungi/genbank | NCBI divisions read |
| `--genbank_fill_groups` | fungi | GenBank genomes only for phyla without RefSeq species |
| `--exclude_genomes` | 0 dropped | genomes listed by hand that never enter the database |
| `--minbp` | 2,000,000 | minimum assembly size (bp) |
| `--min_relative_size` | 0.1 | minimum size as a fraction of the genus median |
| `--holdout_size` | 0 | RefSeq species kept out of every sub-database (0 taken) |
| `--holdout_protect_ranks` | phylum, order | ranks the hold-out never empties |
| `--metaeuk_size` | 5 | RefSeq proteomes in the MetaEuk reference (9 taken) |
| `--calibration_size` | 6 | species per sub-database that calibrate the GA cut-offs |
| `--evalue` | 0.01 | hmmsearch E-value on the calibration genomes |
| `--max_leaf_gap_fraction` | None | leaves with more gaps leave the tree |
| `--iqtree` / `--modelfinder` | true / false | tree method, model selection |
| `--iqmodel` | LG+R7 | substitution model when ModelFinder is off |
| `--seed` | 42 | IQ-TREE and sampling seed |

Every parameter of the run is in `provenance/params.json`.

## Tools

| tool | version |
|---|---|
| ete3 | 3.1.2 |
| famsa | 1.6.1 |
| hmmer | 3.3 |
| iqtree | 2.3.6 |
| metaeuk | 4.a0f584d |
| trimal | v1.4.rev15 |

## Provenance

| file | |
|---|---|
| `provenance/build_summary.tsv` | count after each step, per sub-database |
| `provenance/exclusions.tsv` | every candidate that did not become a leaf, with the stage and reason |
| `provenance/coverage.tsv` | taxa covered by each sub-database |
| `provenance/species_classification.csv` | role of every genome (hold-out, MetaEuk, calibration, remaining) |
| `provenance/taxonomy.tsv` | the taxonomy dump: source, md5, date |
| `provenance/exclude_genomes.tsv` | the genomes excluded by hand, with the reason |
| `provenance/params.json`, `run.txt`, `versions.yml` | parameters, run and tool versions |

## Rebuild

NCBI changes every day. To rebuild this release, pin the NCBI snapshot and the taxonomy of
this build (the assembly summaries are in `<outdir>/provenance/ncbi/summaries/` of the run):

```bash
nextflow run EBI-Metagenomics/eukcc_db -profile codon_slurm \
    --name 2026_11 --outdir <outdir> \
    --summaries <outdir of this build>/provenance/ncbi/summaries \
    --taxdb eukcc2_db_tiny_fungi/etetoolkit/taxa.sqlite \
    --exclude_genomes eukcc2_db_tiny_fungi/provenance/exclude_genomes.tsv \
    --panther_url https://data.pantherdb.org/ftp/panther_library/16.0/PANTHER16.0_ascii.tgz --panther_version 16.0 \
    --cutoff_date 2026-11-01T00:00:00+0000 --modelfinder false --iqmodel LG+R7 --seed 42
```

## Reduced for nf-core tests

This copy is cut down from `eukcc2_db_tiny_fungi.tar.gz` (md5 `39ad789714e92f1551129a6edd2585a9`) to what the
nf-core `eukcc/single` tests need. With `--clade fungi` it gives the same `eukcc.tsv` and `scmg_marker_table.csv.gz`
as the full tiny database for `data/proteomics/database/yeast_UPS.fasta` (`--AA`) and
`data/genomics/eukaryotes/saccharomyces_cerevisiae/genome/genome.fa` (DNA) of nf-core/test-datasets. It is not
meant for real analyses.

| part | full tiny database | this copy |
|---|---|---|
| fungi SCMG profiles | 337, pressed | 24 of the set EukCC picks for `yeast_UPS.fasta` (`provenance/needed_profiles.txt`), text HMM + SSI index |
| fungi SCMG table | 2,565 rows | 191 rows, limited to those 24 profiles |
| MetaEuk reference | 90,548 proteins | 409 proteins hit by the kept SCMGs or the placement markers (hmmsearch, E <= 1e-5) |
| placement search HMM | text + pressed | text only |
| base placement HMMs | 10 markers | empty: `--clade fungi` does not read them, EukCC only checks they exist |

`base` has no SCMG profiles in either copy, so always run it with `--clade fungi`. The reduction is
`provenance/shrink_eukcc_db.sh` (EukCC 2.3.0 and MMseqs2 15.6f452 containers).
