#!/usr/bin/env bash
# Reduce the EukCC 2 tiny fungi database to what the nf-core eukcc/single tests need.
#
# Inputs, in the working directory given as $1:
#   eukcc2_db_tiny_fungi/   the database from https://ftp.ebi.ac.uk/pub/databases/metagenomics/eukcc/eukcc2_db_tiny_fungi.tar.gz
#   needed_profiles.txt     the 24 PANTHER SCMG profiles EukCC selects for data/proteomics/database/yeast_UPS.fasta
#                           (read from the *_GA.csv files of `eukcc single --AA --clade fungi --keep`)
# Output: reduced/eukcc2_db_tiny_fungi/
#
# What is cut, and why the tests still give the same result:
#   - fungi SCMG library: 337 -> 24 profiles, kept as a text HMM with an SSI index instead of pressed files,
#     and the SCMG table limited to those profiles, so set selection can only pick profiles that exist;
#   - MetaEuk reference: only the proteins hit by the kept SCMGs or the placement markers (hmmsearch, E <= 1e-5);
#   - pressed copies of fungi_search.hmm: hmmsearch reads the text file;
#   - base placement HMMs: emptied, `--clade fungi` never reads them, but EukCC checks they exist.
set -euo pipefail
D=$1
cd "$D"
E() { docker run --rm --platform linux/amd64 -v "$D":/data -w /data quay.io/biocontainers/eukcc:2.3.0--pyhdfd78af_0 "$@"; }
M() { docker run --rm --platform linux/amd64 -v "$D":/data -w /data quay.io/biocontainers/mmseqs2:15.6f452--pl5321h6a68c12_3 "$@"; }

SRC=eukcc2_db_tiny_fungi
rm -rf "$D/reduced"
mkdir reduced
cp -R "$SRC" reduced/
OUT=reduced/$SRC
SCMG=$OUT/db_fungi/scmgs

# fungi SCMG profiles and table
E hmmfetch -o sel.hmm -f $SRC/db_fungi/scmgs/fungi_PANTHERv16.0.hmm needed_profiles.txt > /dev/null
rm "$D"/$SCMG/fungi_PANTHERv16.0.hmm*
cp sel.hmm $SCMG/fungi_PANTHERv16.0.hmm
E hmmfetch --index $SCMG/fungi_PANTHERv16.0.hmm > /dev/null
zcat < $SRC/db_fungi/scmgs/fungi_SCMGs.csv.gz | grep -F -w -f needed_profiles.txt | gzip -n > $SCMG/fungi_SCMGs.csv.gz

# MetaEuk reference
M mmseqs convert2fasta $SRC/db_base/metaeukdb/microeuks_metaeuk.db all_metaeuk.faa > /dev/null
cat sel.hmm $SRC/db_fungi/backbone/placement/fungi_search.hmm $SRC/db_base/backbone/placement/base_search.hmm > markers.hmm
E hmmsearch --cpu 4 -E 1e-5 --noali --tblout markers_hits.tbl -o /dev/null markers.hmm all_metaeuk.faa
grep -v '^#' markers_hits.tbl | awk '{print $1}' | sort -u > keep_proteins.txt
awk 'NR==FNR{k[$1]=1;next} /^>/{split(substr($0,2),a," "); p=(a[1] in k)} p' keep_proteins.txt all_metaeuk.faa > kept_metaeuk.faa
rm "$D"/$OUT/db_base/metaeukdb/microeuks_metaeuk.db*
M mmseqs createdb kept_metaeuk.faa $OUT/db_base/metaeukdb/microeuks_metaeuk.db > /dev/null

# placement HMMs
rm "$D"/$OUT/db_fungi/backbone/placement/fungi_search.hmm.h3?
rm "$D"/$OUT/db_base/backbone/placement/base_search.hmm.h3?
: > $OUT/db_base/backbone/placement/base_search.hmm
rm "$D"/$OUT/db_base/backbone/placement/place/*

echo "SCMG profiles: $(grep -c ^NAME $SCMG/fungi_PANTHERv16.0.hmm)"
echo "SCMG table rows: $(zcat < $SCMG/fungi_SCMGs.csv.gz | wc -l | tr -d ' ')"
echo "MetaEuk proteins: $(grep -c '>' all_metaeuk.faa) -> $(grep -c '>' kept_metaeuk.faa)"
du -sh $OUT
