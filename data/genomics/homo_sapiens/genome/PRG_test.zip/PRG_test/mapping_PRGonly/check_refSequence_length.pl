use strict;
use Data::Dumper;

# my $f1_h = readFASTA('output/mapping/2.fa');
# die unless($f1_h->{PRG_2});
# print "Length ", length($f1_h->{PRG_2}), "\n";

my $f2_h = readFASTA('referenceGenome.fa');
die unless($f2_h->{PRG_2});
print "Length ", length($f2_h->{PRG_2}), "\n";

die unless($f2_h->{PRG_551});
print "Length 551: ", length($f2_h->{PRG_551}), "\n";

die unless($f2_h->{PRG_5});
print "Length 5: ", length($f2_h->{PRG_5}), "\n";




sub readFASTA
{
	my $file = shift;	
	my %R;
	
	open(F, '<', $file) or die "Cannot open $file";
	my $currentSequence;
	while(<F>)
	{
		if(($. % 1000000) == 0)
		{
		# 	print "\r", $.;
		}
		
		my $line = $_;
		chomp($line);
		$line =~ s/[\n\r]//g;
		if(substr($line, 0, 1) eq '>')
		{
			$currentSequence = substr($line, 1);
		}
		else
		{
			$R{$currentSequence} .= $line;
		}
	}	
	close(F);
		
	return \%R;
}