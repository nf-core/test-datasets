{
  "version": "1.2",
  "dbname": "AMR_DNA-Clostridioides_difficile.fa",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/amrfinder_index.B7lHPI/db/AMR_DNA-Clostridioides_difficile.fa",
  "number-of-letters": 3301,
  "number-of-sequences": 2,
  "last-updated": "2026-10-16T11:54:00",
  "number-of-volumes": 1,
  "bytes-total": 38172,
  "bytes-to-cache": 1032,
  "files": [
    "AMR_DNA-Clostridioides_difficile.fa.ndb",
    "AMR_DNA-Clostridioides_difficile.fa.nhr",
    "AMR_DNA-Clostridioides_difficile.fa.nin",
    "AMR_DNA-Clostridioides_difficile.fa.not",
    "AMR_DNA-Clostridioides_difficile.fa.nsq",
    "AMR_DNA-Clostridioides_difficile.fa.ntf",
    "AMR_DNA-Clostridioides_difficile.fa.nto"
  ]
}
