{
  "version": "1.2",
  "dbname": "AMR_DNA-Neisseria_gonorrhoeae.fa",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/amrfinder_index.B7lHPI/db/AMR_DNA-Neisseria_gonorrhoeae.fa",
  "number-of-letters": 5561,
  "number-of-sequences": 6,
  "last-updated": "2026-10-16T11:54:00",
  "number-of-volumes": 1,
  "bytes-total": 39489,
  "bytes-to-cache": 1647,
  "files": [
    "AMR_DNA-Neisseria_gonorrhoeae.fa.ndb",
    "AMR_DNA-Neisseria_gonorrhoeae.fa.nhr",
    "AMR_DNA-Neisseria_gonorrhoeae.fa.nin",
    "AMR_DNA-Neisseria_gonorrhoeae.fa.not",
    "AMR_DNA-Neisseria_gonorrhoeae.fa.nsq",
    "AMR_DNA-Neisseria_gonorrhoeae.fa.ntf",
    "AMR_DNA-Neisseria_gonorrhoeae.fa.nto"
  ]
}
