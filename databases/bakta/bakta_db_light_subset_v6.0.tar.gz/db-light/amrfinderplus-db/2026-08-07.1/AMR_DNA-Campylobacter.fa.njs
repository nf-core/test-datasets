{
  "version": "1.2",
  "dbname": "AMR_DNA-Campylobacter.fa",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/amrfinder_index.B7lHPI/db/AMR_DNA-Campylobacter.fa",
  "number-of-letters": 6720,
  "number-of-sequences": 3,
  "last-updated": "2026-10-16T11:54:00",
  "number-of-volumes": 1,
  "bytes-total": 39156,
  "bytes-to-cache": 1884,
  "files": [
    "AMR_DNA-Campylobacter.fa.ndb",
    "AMR_DNA-Campylobacter.fa.nhr",
    "AMR_DNA-Campylobacter.fa.nin",
    "AMR_DNA-Campylobacter.fa.not",
    "AMR_DNA-Campylobacter.fa.nsq",
    "AMR_DNA-Campylobacter.fa.ntf",
    "AMR_DNA-Campylobacter.fa.nto"
  ]
}
