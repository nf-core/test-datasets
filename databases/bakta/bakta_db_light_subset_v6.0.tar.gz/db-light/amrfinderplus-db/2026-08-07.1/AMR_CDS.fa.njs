{
  "version": "1.2",
  "dbname": "AMR_CDS.fa",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/amrfinder_index.B7lHPI/db/AMR_CDS.fa",
  "number-of-letters": 22410,
  "number-of-sequences": 21,
  "last-updated": "2026-10-16T11:54:00",
  "number-of-volumes": 1,
  "bytes-total": 46963,
  "bytes-to-cache": 6004,
  "files": [
    "AMR_CDS.fa.ndb",
    "AMR_CDS.fa.nhr",
    "AMR_CDS.fa.nin",
    "AMR_CDS.fa.not",
    "AMR_CDS.fa.nsq",
    "AMR_CDS.fa.ntf",
    "AMR_CDS.fa.nto"
  ]
}
