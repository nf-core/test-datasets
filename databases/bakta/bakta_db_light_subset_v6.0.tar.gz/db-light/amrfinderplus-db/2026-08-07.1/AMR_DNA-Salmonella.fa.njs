{
  "version": "1.2",
  "dbname": "AMR_DNA-Salmonella.fa",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/amrfinder_index.B7lHPI/db/AMR_DNA-Salmonella.fa",
  "number-of-letters": 1536,
  "number-of-sequences": 1,
  "last-updated": "2026-10-16T11:54:00",
  "number-of-volumes": 1,
  "bytes-total": 37563,
  "bytes-to-cache": 554,
  "files": [
    "AMR_DNA-Salmonella.fa.ndb",
    "AMR_DNA-Salmonella.fa.nhr",
    "AMR_DNA-Salmonella.fa.nin",
    "AMR_DNA-Salmonella.fa.not",
    "AMR_DNA-Salmonella.fa.nsq",
    "AMR_DNA-Salmonella.fa.ntf",
    "AMR_DNA-Salmonella.fa.nto"
  ]
}
