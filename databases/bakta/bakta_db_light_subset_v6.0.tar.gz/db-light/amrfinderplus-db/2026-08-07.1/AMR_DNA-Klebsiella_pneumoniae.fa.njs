{
  "version": "1.2",
  "dbname": "AMR_DNA-Klebsiella_pneumoniae.fa",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/amrfinder_index.B7lHPI/db/AMR_DNA-Klebsiella_pneumoniae.fa",
  "number-of-letters": 300,
  "number-of-sequences": 1,
  "last-updated": "2026-10-16T11:54:00",
  "number-of-volumes": 1,
  "bytes-total": 37283,
  "bytes-to-cache": 269,
  "files": [
    "AMR_DNA-Klebsiella_pneumoniae.fa.ndb",
    "AMR_DNA-Klebsiella_pneumoniae.fa.nhr",
    "AMR_DNA-Klebsiella_pneumoniae.fa.nin",
    "AMR_DNA-Klebsiella_pneumoniae.fa.not",
    "AMR_DNA-Klebsiella_pneumoniae.fa.nsq",
    "AMR_DNA-Klebsiella_pneumoniae.fa.ntf",
    "AMR_DNA-Klebsiella_pneumoniae.fa.nto"
  ]
}
