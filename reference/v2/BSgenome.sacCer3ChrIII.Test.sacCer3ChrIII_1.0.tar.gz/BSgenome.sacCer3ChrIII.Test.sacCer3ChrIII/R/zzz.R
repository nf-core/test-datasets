###
###

.pkgname <- "BSgenome.sacCer3ChrIII.Test.sacCer3ChrIII"

.seqnames <- NULL

.circ_seqs <- character(0)

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Saccharomyces cerevisiae",
        common_name="Yeast",
        genome="sacCer3ChrIII",
        provider="custom",
        release_date="April 2011",
        source_url="https://hgdownload.soe.ucsc.edu/goldenPath/sacCer3/bigZips/",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "sacCer3ChrIII"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

