{
  "version": "1.2",
  "dbname": "human_tr_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/human_tr_j.fasta",
  "number-of-letters": 5908,
  "number-of-sequences": 101,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 60857,
  "bytes-to-cache": 2971,
  "files": [
    "human_tr_j.ndb",
    "human_tr_j.nhr",
    "human_tr_j.nin",
    "human_tr_j.nog",
    "human_tr_j.nos",
    "human_tr_j.not",
    "human_tr_j.nsq",
    "human_tr_j.ntf",
    "human_tr_j.nto"
  ]
}
