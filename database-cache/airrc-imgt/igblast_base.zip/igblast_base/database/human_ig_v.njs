{
  "version": "1.2",
  "dbname": "human_ig_v",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/human_ig_v.fasta",
  "number-of-letters": 101162,
  "number-of-sequences": 342,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 122308,
  "bytes-to-cache": 29864,
  "files": [
    "human_ig_v.ndb",
    "human_ig_v.nhr",
    "human_ig_v.nin",
    "human_ig_v.nog",
    "human_ig_v.nos",
    "human_ig_v.not",
    "human_ig_v.nsq",
    "human_ig_v.ntf",
    "human_ig_v.nto"
  ]
}
