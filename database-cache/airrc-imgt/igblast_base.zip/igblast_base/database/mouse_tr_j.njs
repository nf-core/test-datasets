{
  "version": "1.2",
  "dbname": "mouse_tr_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/mouse_tr_j.fasta",
  "number-of-letters": 5590,
  "number-of-sequences": 96,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 60290,
  "bytes-to-cache": 2826,
  "files": [
    "mouse_tr_j.ndb",
    "mouse_tr_j.nhr",
    "mouse_tr_j.nin",
    "mouse_tr_j.nog",
    "mouse_tr_j.nos",
    "mouse_tr_j.not",
    "mouse_tr_j.nsq",
    "mouse_tr_j.ntf",
    "mouse_tr_j.nto"
  ]
}
