{
  "version": "1.2",
  "dbname": "human_ig_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/human_ig_j.fasta",
  "number-of-letters": 991,
  "number-of-sequences": 23,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 51892,
  "bytes-to-cache": 756,
  "files": [
    "human_ig_j.ndb",
    "human_ig_j.nhr",
    "human_ig_j.nin",
    "human_ig_j.nog",
    "human_ig_j.nos",
    "human_ig_j.not",
    "human_ig_j.nsq",
    "human_ig_j.ntf",
    "human_ig_j.nto"
  ]
}
