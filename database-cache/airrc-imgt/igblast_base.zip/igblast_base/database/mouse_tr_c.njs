{
  "version": "1.2",
  "dbname": "mouse_tr_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/mouse_tr_c.fasta",
  "number-of-letters": 6705,
  "number-of-sequences": 13,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 52393,
  "bytes-to-cache": 2101,
  "files": [
    "mouse_tr_c.ndb",
    "mouse_tr_c.nhr",
    "mouse_tr_c.nin",
    "mouse_tr_c.nog",
    "mouse_tr_c.nos",
    "mouse_tr_c.not",
    "mouse_tr_c.nsq",
    "mouse_tr_c.ntf",
    "mouse_tr_c.nto"
  ]
}
