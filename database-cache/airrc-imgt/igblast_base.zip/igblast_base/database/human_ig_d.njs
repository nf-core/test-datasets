{
  "version": "1.2",
  "dbname": "human_ig_d",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/human_ig_d.fasta",
  "number-of-letters": 754,
  "number-of-sequences": 31,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 52771,
  "bytes-to-cache": 799,
  "files": [
    "human_ig_d.ndb",
    "human_ig_d.nhr",
    "human_ig_d.nin",
    "human_ig_d.nog",
    "human_ig_d.nos",
    "human_ig_d.not",
    "human_ig_d.nsq",
    "human_ig_d.ntf",
    "human_ig_d.nto"
  ]
}
