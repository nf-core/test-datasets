{
  "version": "1.2",
  "dbname": "mouse_ig_v",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/mouse_ig_v.fasta",
  "number-of-letters": 57601,
  "number-of-sequences": 196,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 92905,
  "bytes-to-cache": 17085,
  "files": [
    "mouse_ig_v.ndb",
    "mouse_ig_v.nhr",
    "mouse_ig_v.nin",
    "mouse_ig_v.nog",
    "mouse_ig_v.nos",
    "mouse_ig_v.not",
    "mouse_ig_v.nsq",
    "mouse_ig_v.ntf",
    "mouse_ig_v.nto"
  ]
}
