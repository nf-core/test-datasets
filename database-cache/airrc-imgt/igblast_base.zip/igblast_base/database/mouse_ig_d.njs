{
  "version": "1.2",
  "dbname": "mouse_ig_d",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/mouse_ig_d.fasta",
  "number-of-letters": 135,
  "number-of-sequences": 8,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 50312,
  "bytes-to-cache": 356,
  "files": [
    "mouse_ig_d.ndb",
    "mouse_ig_d.nhr",
    "mouse_ig_d.nin",
    "mouse_ig_d.nog",
    "mouse_ig_d.nos",
    "mouse_ig_d.not",
    "mouse_ig_d.nsq",
    "mouse_ig_d.ntf",
    "mouse_ig_d.nto"
  ]
}
