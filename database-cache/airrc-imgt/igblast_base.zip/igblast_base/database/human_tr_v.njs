{
  "version": "1.2",
  "dbname": "human_tr_v",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/human_tr_v.fasta",
  "number-of-letters": 100096,
  "number-of-sequences": 355,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 122474,
  "bytes-to-cache": 29718,
  "files": [
    "human_tr_v.ndb",
    "human_tr_v.nhr",
    "human_tr_v.nin",
    "human_tr_v.nog",
    "human_tr_v.nos",
    "human_tr_v.not",
    "human_tr_v.nsq",
    "human_tr_v.ntf",
    "human_tr_v.nto"
  ]
}
