{
  "version": "1.2",
  "dbname": "mouse_tr_d",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/mouse_tr_d.fasta",
  "number-of-letters": 60,
  "number-of-sequences": 5,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 49924,
  "bytes-to-cache": 300,
  "files": [
    "mouse_tr_d.ndb",
    "mouse_tr_d.nhr",
    "mouse_tr_d.nin",
    "mouse_tr_d.nog",
    "mouse_tr_d.nos",
    "mouse_tr_d.not",
    "mouse_tr_d.nsq",
    "mouse_tr_d.ntf",
    "mouse_tr_d.nto"
  ]
}
