{
  "version": "1.2",
  "dbname": "mouse_ig_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/mouse_ig_j.fasta",
  "number-of-letters": 894,
  "number-of-sequences": 22,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 51992,
  "bytes-to-cache": 720,
  "files": [
    "mouse_ig_j.ndb",
    "mouse_ig_j.nhr",
    "mouse_ig_j.nin",
    "mouse_ig_j.nog",
    "mouse_ig_j.nos",
    "mouse_ig_j.not",
    "mouse_ig_j.nsq",
    "mouse_ig_j.ntf",
    "mouse_ig_j.nto"
  ]
}
