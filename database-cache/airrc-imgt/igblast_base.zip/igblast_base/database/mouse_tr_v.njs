{
  "version": "1.2",
  "dbname": "mouse_tr_v",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/mouse_tr_v.fasta",
  "number-of-letters": 107025,
  "number-of-sequences": 387,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 128075,
  "bytes-to-cache": 31875,
  "files": [
    "mouse_tr_v.ndb",
    "mouse_tr_v.nhr",
    "mouse_tr_v.nin",
    "mouse_tr_v.nog",
    "mouse_tr_v.nos",
    "mouse_tr_v.not",
    "mouse_tr_v.nsq",
    "mouse_tr_v.ntf",
    "mouse_tr_v.nto"
  ]
}
