{
  "version": "1.2",
  "dbname": "human_tr_d",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/human_tr_d.fasta",
  "number-of-letters": 74,
  "number-of-sequences": 6,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 50025,
  "bytes-to-cache": 317,
  "files": [
    "human_tr_d.ndb",
    "human_tr_d.nhr",
    "human_tr_d.nin",
    "human_tr_d.nog",
    "human_tr_d.nos",
    "human_tr_d.not",
    "human_tr_d.nsq",
    "human_tr_d.ntf",
    "human_tr_d.nto"
  ]
}
