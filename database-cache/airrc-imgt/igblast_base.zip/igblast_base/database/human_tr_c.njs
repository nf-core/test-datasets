{
  "version": "1.2",
  "dbname": "human_tr_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/human_tr_c.fasta",
  "number-of-letters": 12310,
  "number-of-sequences": 23,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 54732,
  "bytes-to-cache": 3600,
  "files": [
    "human_tr_c.ndb",
    "human_tr_c.nhr",
    "human_tr_c.nin",
    "human_tr_c.nog",
    "human_tr_c.nos",
    "human_tr_c.not",
    "human_tr_c.nsq",
    "human_tr_c.ntf",
    "human_tr_c.nto"
  ]
}
