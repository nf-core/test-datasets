{
  "version": "1.2",
  "dbname": "human_ig_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/human_ig_c.fasta",
  "number-of-letters": 369012,
  "number-of-sequences": 326,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 200024,
  "bytes-to-cache": 96588,
  "files": [
    "human_ig_c.ndb",
    "human_ig_c.nhr",
    "human_ig_c.nin",
    "human_ig_c.nog",
    "human_ig_c.nos",
    "human_ig_c.not",
    "human_ig_c.nsq",
    "human_ig_c.ntf",
    "human_ig_c.nto"
  ]
}
