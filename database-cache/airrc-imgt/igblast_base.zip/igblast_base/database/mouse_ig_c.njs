{
  "version": "1.2",
  "dbname": "mouse_ig_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/home/gisela/Projects/Pipelines/test-airrflow-fetchdb/work/b8/daac04832abb27081b620cf333b82a/igblast_base/fasta/mouse_ig_c.fasta",
  "number-of-letters": 42360,
  "number-of-sequences": 41,
  "last-updated": "2026-05-12T02:41:00",
  "number-of-volumes": 1,
  "bytes-total": 63951,
  "bytes-to-cache": 11325,
  "files": [
    "mouse_ig_c.ndb",
    "mouse_ig_c.nhr",
    "mouse_ig_c.nin",
    "mouse_ig_c.nog",
    "mouse_ig_c.nos",
    "mouse_ig_c.not",
    "mouse_ig_c.nsq",
    "mouse_ig_c.ntf",
    "mouse_ig_c.nto"
  ]
}
